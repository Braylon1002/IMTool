## IMTools
this package aims to contain Influence Maximization tools as much as possible.

## Functions
- LFA
- IMRank